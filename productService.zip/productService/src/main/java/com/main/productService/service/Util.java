package com.main.productService.service;

public interface Util {
	
	public boolean isNeitherNullNorEmpty(Object obj);
	
	

}
