package com.main.productService.serviceImpl;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.productService.ProductRepo;
import com.main.productService.entity.ProductEntity;
import com.main.productService.service.ProductService;
import com.main.productService.service.Util;

import lombok.extern.log4j.Log4j2;


@Service
@Log4j2
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductRepo productRepo;
	
	@Autowired
	Util util;

	

	@Override
	public int insertProduct(ProductEntity product) {
		try {
		ProductEntity result = productRepo.save(product);
		log.info("Product :: "+result.toString());
		if(util.isNeitherNullNorEmpty(result)) {
			return 1;
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return 0;
	}



	@Override
	public Optional<ProductEntity> getProductDetails(int productId) {
		
		Optional<ProductEntity> findById = productRepo.findById(productId);
		
		
		return findById;
	}

}
