package com.main.productService.service;


import java.math.BigDecimal;
import java.util.Optional;

import com.main.productService.entity.ProductEntity;

public interface ProductService {
	

	public int insertProduct(ProductEntity product);

	public Optional<ProductEntity> getProductDetails(int productId);
	

}
